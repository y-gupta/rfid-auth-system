#include "mainwindow.h"
#include "ui_mainwindow.h"

void MainWindow::gotoAdmin(){
    ui->stackedWidget->setCurrentIndex(STAFF_LOGIN);
}
